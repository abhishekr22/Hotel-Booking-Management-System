import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deleteflights',
  templateUrl: './deleteflights.component.html',
  styleUrls: ['./deleteflights.component.css']
})
export class DeleteflightsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
