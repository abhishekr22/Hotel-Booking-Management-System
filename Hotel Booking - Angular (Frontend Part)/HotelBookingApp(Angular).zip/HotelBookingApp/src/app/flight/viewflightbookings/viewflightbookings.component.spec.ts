import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewflightbookingsComponent } from './viewflightbookings.component';

describe('ViewflightbookingsComponent', () => {
  let component: ViewflightbookingsComponent;
  let fixture: ComponentFixture<ViewflightbookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewflightbookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewflightbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
