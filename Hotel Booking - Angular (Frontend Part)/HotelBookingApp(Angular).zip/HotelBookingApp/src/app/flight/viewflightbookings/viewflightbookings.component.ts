import { Component, OnInit } from '@angular/core';
import { ReviewService } from 'src/app/review.service';
import { Flightbooking } from 'src/app/flightbooking';
import { Router } from '@angular/router';
@Component({
  selector: 'app-viewflightbookings',
  templateUrl: './viewflightbookings.component.html',
  styleUrls: ['./viewflightbookings.component.css']
})
export class ViewflightbookingsComponent implements OnInit {
  flightbookings:Flightbooking[]=[];
  searchtext!:any;
  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.getfbooks();
  }
  getfbooks(){
    this.service.getflightbookings().subscribe(data=>{this.flightbookings=data});
  }
}
