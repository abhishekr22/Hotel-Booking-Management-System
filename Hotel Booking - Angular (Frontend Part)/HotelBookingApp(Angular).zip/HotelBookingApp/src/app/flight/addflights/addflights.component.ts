import { Component, OnInit } from '@angular/core';
import { Flight } from 'src/app/flight';
import { Router } from '@angular/router';
import { ReviewService } from 'src/app/review.service';
@Component({
  selector: 'app-addflights',
  templateUrl: './addflights.component.html',
  styleUrls: ['./addflights.component.css']
})
export class AddflightsComponent implements OnInit {

  flight:Flight=new Flight();
  constructor(private rservice:ReviewService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    this.rservice.addflight(this.flight).subscribe(data=>{alert("Flight Added Successfully");this.gotoflights()},error => alert("Check Your Details and try again !!!"));
  }
  gotoflights(){
    this.router.navigate(['/flight']);
  }
}
