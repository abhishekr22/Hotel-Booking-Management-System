import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { ReviewService } from '../review.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {

  flights:Flight[]=[];
  searchtext!:any;


  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.getflights()
  }
  getflights(){
    
    this.service.getflights().subscribe(data=>{this.flights=data});

  }

  deleteflight(flight_id:number){
    this.service.deleteflight(flight_id).subscribe(data=>{alert("Flight Deleted Successfully");this.getflights();})
  
  }
  bookflight(){
    this.router.navigate(['/flightbookings']);

  }
  viewreviews(flight_id:number){
    this.router.navigate(['flightreviews',flight_id]);
  }
  flightbookings(){
    this.router.navigate(['/viewflightbookings']);
  }
  addflights(){
    this.router.navigate(['/addflights']);
  }
}
