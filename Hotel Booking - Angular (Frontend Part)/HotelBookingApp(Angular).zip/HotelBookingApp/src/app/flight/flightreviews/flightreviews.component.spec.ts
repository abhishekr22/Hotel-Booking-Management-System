import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightreviewsComponent } from './flightreviews.component';

describe('FlightreviewsComponent', () => {
  let component: FlightreviewsComponent;
  let fixture: ComponentFixture<FlightreviewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FlightreviewsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightreviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
