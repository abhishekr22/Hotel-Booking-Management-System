import { Component, OnInit } from '@angular/core';
import { Review } from 'src/app/review';
import { ActivatedRoute } from '@angular/router';
import { ReviewService } from 'src/app/review.service';
@Component({
  selector: 'app-flightreviews',
  templateUrl: './flightreviews.component.html',
  styleUrls: ['./flightreviews.component.css']
})
export class FlightreviewsComponent implements OnInit {

  flight_id!:number;
  reviews:Review[]=[];
  searchtext!:any;

  constructor(private service:ReviewService,private router: ActivatedRoute) { }

ngOnInit(): void {
  this.flight_id=this.router.snapshot.params['flight_id'];
  this.service.viewreviewsserviceid(this.flight_id).subscribe(data=>{this.reviews=data});
}
}
