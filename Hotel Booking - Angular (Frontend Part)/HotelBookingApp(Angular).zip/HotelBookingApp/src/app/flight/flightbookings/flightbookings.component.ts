import { Component, OnInit } from '@angular/core';
import { Flightbooking } from 'src/app/flightbooking';
import { ReviewService } from 'src/app/review.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-flightbookings',
  templateUrl: './flightbookings.component.html',
  styleUrls: ['./flightbookings.component.css']
})
export class FlightbookingsComponent implements OnInit {

  flight:Flightbooking = new Flightbooking();

  constructor(private rservice:ReviewService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    this.rservice.bookflight(this.flight).subscribe(data=>{alert("Flight Booked Successfully");this.gotoreview()},error => alert("Check Your Details and try again !!!"));
  }
  gotoflightbookings(){
    this.router.navigate(['/viewflightbookings']);
  }
  gotoreview(){
    this.router.navigate(['/createreview'])
  }

}

