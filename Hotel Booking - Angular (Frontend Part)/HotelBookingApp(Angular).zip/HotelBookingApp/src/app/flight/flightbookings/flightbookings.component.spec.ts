import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightbookingsComponent } from './flightbookings.component';

describe('FlightbookingsComponent', () => {
  let component: FlightbookingsComponent;
  let fixture: ComponentFixture<FlightbookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FlightbookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
