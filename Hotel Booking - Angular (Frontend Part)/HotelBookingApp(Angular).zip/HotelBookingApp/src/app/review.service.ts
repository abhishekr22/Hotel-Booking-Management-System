import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Review } from './review';
import { Register } from './register';
import { User } from './user';
import { Hotel } from './hotel';
import { Flight } from './flight';
import { Flightbooking } from './flightbooking';
import { Hotelbooking } from './hotelbooking';
import { Passengers } from './passengers';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  constructor(private http:HttpClient) { }
  getreviews() :Observable<Review[]>{
    return this.http.get<Review[]>(`${"http://localhost:8090/review/allreviews"}`);
  }
  addreviews(review:Review): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/review/savereview"}`,review);
  }
  deletereview(reviewid:number){
    return this.http.delete(`${"http://localhost:8090/review/deletereview"}/${reviewid}`);
  }
  register(register:Register): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/customer/save"}`,register);
  }
  login(user:User): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/customer/login"}`,user);
  }
  sortratings() :Observable<Review[]>{
    return this.http.get<Review[]>(`${"http://localhost:8090/review/allreviews/sortrating"}`);
  }
  gethotels() :Observable<Hotel[]>{
    return this.http.get<Hotel[]>(`${"http://localhost:8090/hotel/list"}`); 
  }
  getflights() :Observable<Flight[]>{
    return this.http.get<Flight[]>(`${"http://localhost:8090/flight/all"}`);
  }
  gethotelbookings():Observable<Hotelbooking[]> {
    return this.http.get<Hotelbooking[]>(`${"http://localhost:8090/customer/hbook"}`);

  }
  deletehotel(hotel_id:number){
    return this.http.delete(`${"http://localhost:8090/hotel/delete"}/${hotel_id}`);
  }
  addhotel(hotel: Hotel): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/hotel/save"}`,hotel);
  }
  
  getflightbookings():Observable<Flightbooking[]>{
    return this.http.get<Flightbooking[]>(`${"http://localhost:8090/customer/fbook"}`);

  }
  deleteflight(flight_id:number){
    return this.http.delete(`${"http://localhost:8090/flight/delete"}/${flight_id}`);

  }
  addflight(flight:Flight): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/flight/saveflight"}`,flight);

  }
  viewreviewsserviceid(service_id:number):Observable<Review[]>{
    return this.http.get<Review[]>(`${"http://localhost:8090/review/getreviews"}/${service_id}`);

  }
  bookflight(flightbooking:Flightbooking): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/customer/fbook"}`,flightbooking);
  }
  bookhotel(hotelbooking:Hotelbooking): Observable<Object>{
    return this.http.post(`${"http://localhost:8090/customer/hbook"}`,hotelbooking);

  }
  getusers():Observable<Passengers[]>{
    return this.http.get<Passengers[]>(`${"http://localhost:8090/customer/all"}`);

  }
  deleteuser(user_id:number){
    return this.http.delete(`${"http://localhost:8090/customer"}/${user_id}`);
  }
  viewuser(user_id:number):Observable<Passengers>{
    return this.http.get<Passengers>(`${"http://localhost:8090/customer"}/${user_id}`)
  }


  
}
