import { NumberValueAccessor } from "@angular/forms";

export class Review {
    review_id!: number;
    feedback!:string;
    rating!:number;
    service_id!:number;
    user_id!:number;
    hotelname!:string;
    hotelcity!:string;
}
