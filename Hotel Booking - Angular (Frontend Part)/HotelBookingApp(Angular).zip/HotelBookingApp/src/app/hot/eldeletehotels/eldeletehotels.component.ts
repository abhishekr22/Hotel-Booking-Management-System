import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eldeletehotels',
  templateUrl: './eldeletehotels.component.html',
  styleUrls: ['./eldeletehotels.component.css']
})
export class EldeletehotelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
