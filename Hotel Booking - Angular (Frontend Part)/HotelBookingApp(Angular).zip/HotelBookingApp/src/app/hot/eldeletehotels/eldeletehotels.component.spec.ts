import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EldeletehotelsComponent } from './eldeletehotels.component';

describe('EldeletehotelsComponent', () => {
  let component: EldeletehotelsComponent;
  let fixture: ComponentFixture<EldeletehotelsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EldeletehotelsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EldeletehotelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
