import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightComponent } from './flight/flight.component';
import { HomeComponent } from './home/home.component';
import { HotelComponent } from './hotel/hotel.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { CreatereviewComponent } from './review/createreview/createreview.component';
import { ReviewComponent } from './review/review.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuardService } from './auth-guard.service';
import { AddflightsComponent } from './flight/addflights/addflights.component';
import { AddhotelsComponent } from './hotel/addhotels/addhotels.component';
import { FlightbookingsComponent } from './flight/flightbookings/flightbookings.component';
import { HotelbookingsComponent } from './hotel/hotelbookings/hotelbookings.component';
import { ViewflightbookingsComponent } from './flight/viewflightbookings/viewflightbookings.component';
import { ViewhotelbookingsComponent } from './hotel/viewhotelbookings/viewhotelbookings.component';
import { FlightreviewsComponent } from './flight/flightreviews/flightreviews.component';
import { HotelreviewsComponent } from './hotel/hotelreviews/hotelreviews.component';
import { UsersComponent } from './users/users.component';
import { ViewuserComponent } from './users/viewuser/viewuser.component';
const routes: Routes = [
  {path:'home', component: HomeComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'review', component:ReviewComponent,canActivate:[AuthGuardService]},
  {path:'logout', component: LogoutComponent,canActivate:[AuthGuardService]},
  {path:'createreview',component:CreatereviewComponent,canActivate:[AuthGuardService]},
  {path:'hotel',component:HotelComponent,canActivate:[AuthGuardService]},
  {path:'flight',component:FlightComponent,canActivate:[AuthGuardService]},
  {path:'flightbookings',component:FlightbookingsComponent,canActivate:[AuthGuardService]},
  {path:'hotelbookings',component:HotelbookingsComponent,canActivate:[AuthGuardService]},
  {path:'addflights',component:AddflightsComponent,canActivate:[AuthGuardService]},
  {path:'addhotels',component:AddhotelsComponent,canActivate:[AuthGuardService]},
  {path:'viewhotelbookings',component:ViewhotelbookingsComponent,canActivate:[AuthGuardService]},
  {path:'viewflightbookings',component:ViewflightbookingsComponent,canActivate:[AuthGuardService]},
  {path:'flightreviews/:flight_id',component:FlightreviewsComponent,canActivate:[AuthGuardService]},
  {path:'hotelreviews/:hotel_id',component:HotelreviewsComponent,canActivate:[AuthGuardService]},
  {path:'users',component:UsersComponent,canActivate:[AuthGuardService]},
  {path:'userdetails/:user_id',component:ViewuserComponent,canActivate:[AuthGuardService]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
