import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletehotels',
  templateUrl: './deletehotels.component.html',
  styleUrls: ['./deletehotels.component.css']
})
export class DeletehotelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
