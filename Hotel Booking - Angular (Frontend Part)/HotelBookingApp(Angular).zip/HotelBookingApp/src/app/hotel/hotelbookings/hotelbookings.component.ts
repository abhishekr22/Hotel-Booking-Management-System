import { Component, OnInit } from '@angular/core';
import { Hotelbooking } from 'src/app/hotelbooking';
import { ReviewService } from 'src/app/review.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-hotelbookings',
  templateUrl: './hotelbookings.component.html',
  styleUrls: ['./hotelbookings.component.css']
})
export class HotelbookingsComponent implements OnInit {
  hotel:Hotelbooking = new Hotelbooking();

  constructor(private rservice:ReviewService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(){
    this.rservice.bookhotel(this.hotel).subscribe(data=>{alert("Hotel Booked Successfully"); this.gotoreviews()},error => alert("Check Your Details and try again !!!"));
  }
  gotoreviews(){
    this.router.navigate(['/createreview']);
  }
  gotohotelbookings(){
    this.router.navigate(['/viewhotelbookings']);
  }

}
