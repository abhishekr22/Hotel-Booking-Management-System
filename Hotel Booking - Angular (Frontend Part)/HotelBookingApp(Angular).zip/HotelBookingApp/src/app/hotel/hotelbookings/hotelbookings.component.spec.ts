import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelbookingsComponent } from './hotelbookings.component';

describe('HotelbookingsComponent', () => {
  let component: HotelbookingsComponent;
  let fixture: ComponentFixture<HotelbookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotelbookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
