import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Hotelbooking } from 'src/app/hotelbooking';
import { ReviewService } from 'src/app/review.service';
@Component({
  selector: 'app-viewhotelbookings',
  templateUrl: './viewhotelbookings.component.html',
  styleUrls: ['./viewhotelbookings.component.css']
})
export class ViewhotelbookingsComponent implements OnInit {
  
  hotelbookings:Hotelbooking[]=[];
   searchtext!:any;
  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.gethotelbookings();

  }

  gethotelbookings(){
    this.service.gethotelbookings().subscribe(data=>{this.hotelbookings=data});
  }
  


}
