import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewhotelbookingsComponent } from './viewhotelbookings.component';

describe('ViewhotelbookingsComponent', () => {
  let component: ViewhotelbookingsComponent;
  let fixture: ComponentFixture<ViewhotelbookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewhotelbookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewhotelbookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
