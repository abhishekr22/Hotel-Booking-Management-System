import { Component, OnInit } from '@angular/core';
import { Hotel } from 'src/app/hotel';
import { Router } from '@angular/router';
import { ReviewService } from 'src/app/review.service';
@Component({
  selector: 'app-addhotels',
  templateUrl: './addhotels.component.html',
  styleUrls: ['./addhotels.component.css']
})
export class AddhotelsComponent implements OnInit {
  hotel:Hotel = new Hotel();

  constructor(private rservice:ReviewService,private router:Router) { }

  ngOnInit(): void {
  }
  
onSubmit(){
  this.rservice.addhotel(this.hotel).subscribe(data=>{alert("Hotel Added Successfully");this.gotohotels()},error => alert("Check Your Details and try again !!!"));
}
gotohotels(){
  this.router.navigate(['/hotel']);
}

}
