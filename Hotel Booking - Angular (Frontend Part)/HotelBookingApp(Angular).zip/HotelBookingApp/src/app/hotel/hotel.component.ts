import { Component, OnInit } from '@angular/core';
import { Hotel } from '../hotel';
import { ReviewService } from '../review.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {
  
  hotels:Hotel[]=[];
  searchtext!:any;

  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.gethotels()
  }
  gethotels(){
    
    this.service.gethotels().subscribe(data=>{this.hotels=data});

  }
  deletehotel(hotel_id:number){
    this.service.deletehotel(hotel_id).subscribe(data=>{alert("Hotel Deleted Successfully");this.gethotels();})

  }
  bookhotel(){
    this.router.navigate(['/hotelbookings']);

  }
  viewhreviews(){

  }
  hotelbookings(){
    this.router.navigate(['/viewhotelbookings']);
  }
  addhotels(){
    this.router.navigate(['/addhotels']);
  }
  hotelreviews(hotel_id:number){
    this.router.navigate(['hotelreviews',hotel_id]);
  }

}
