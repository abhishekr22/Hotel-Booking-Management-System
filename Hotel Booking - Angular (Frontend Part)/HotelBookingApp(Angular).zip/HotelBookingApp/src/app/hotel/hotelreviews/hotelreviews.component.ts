import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReviewService } from 'src/app/review.service';
import { Review } from 'src/app/review';
@Component({
  selector: 'app-hotelreviews',
  templateUrl: './hotelreviews.component.html',
  styleUrls: ['./hotelreviews.component.css']
})
export class HotelreviewsComponent implements OnInit {

  hotel_id!:number;
  reviews: Review[]=[];
  searchtext!:any;

  constructor(private service:ReviewService,private router: ActivatedRoute) { }

  ngOnInit(): void {
    this.hotel_id=this.router.snapshot.params['hotel_id'];
    this.service.viewreviewsserviceid(this.hotel_id).subscribe(data=>{this.reviews=data});
  }

}
