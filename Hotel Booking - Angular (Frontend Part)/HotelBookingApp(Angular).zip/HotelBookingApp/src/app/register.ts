export class Register {
    user_id!:number;
	user_name!:string;
	email!:string;
	password!:string;
	mobile!:string;
	address!:string;
}
