export class Flight {
    flight_id!:number
	flight_name!:string;
    avg_rate!:number;
	avg_rating!:number;
    email!:string;
    phone1!:string;
	website!:string;
	destination!:string;
	departure!:string;
	flightcapacity!:number;
	count_of_booking!:number;

}
