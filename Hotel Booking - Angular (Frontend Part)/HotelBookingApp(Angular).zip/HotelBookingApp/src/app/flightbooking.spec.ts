import { Flightbooking } from './flightbooking';

describe('Flightbooking', () => {
  it('should create an instance', () => {
    expect(new Flightbooking()).toBeTruthy();
  });
});
