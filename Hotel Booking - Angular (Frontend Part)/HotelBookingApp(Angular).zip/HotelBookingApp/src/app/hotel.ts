export class Hotel {

	hotel_id!:number;
	city!:string;
	hotel_name!:string;
	address!:string;
    email!:string;
    avg_cost!:number;
	avg_rating!:number;
    phone!:string;
    website!:string;
	no_of_rooms!:number;
	count_of_booking!:number;
}
