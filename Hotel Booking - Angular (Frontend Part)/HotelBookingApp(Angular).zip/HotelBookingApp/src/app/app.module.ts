import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HotelComponent } from './hotel/hotel.component';
import { FlightComponent } from './flight/flight.component';
import { ReviewComponent } from './review/review.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CreatereviewComponent } from './review/createreview/createreview.component';
import { DeletereviewComponent } from './review/deletereview/deletereview.component';
import { LogoutComponent } from './logout/logout.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { FlightbookingsComponent } from './flight/flightbookings/flightbookings.component';
import { AddflightsComponent } from './flight/addflights/addflights.component';
import { DeleteflightsComponent } from './flight/deleteflights/deleteflights.component';
import { HotelbookingsComponent } from './hotel/hotelbookings/hotelbookings.component';
import { AddhotelsComponent } from './hotel/addhotels/addhotels.component';
import { EldeletehotelsComponent } from './hot/eldeletehotels/eldeletehotels.component';
import { DeletehotelsComponent } from './hotel/deletehotels/deletehotels.component';
import { ViewhotelbookingsComponent } from './hotel/viewhotelbookings/viewhotelbookings.component';
import { ViewflightbookingsComponent } from './flight/viewflightbookings/viewflightbookings.component';
import { FlightreviewsComponent } from './flight/flightreviews/flightreviews.component';
import { HotelreviewsComponent } from './hotel/hotelreviews/hotelreviews.component';
import { UsersComponent } from './users/users.component';
import { ViewuserComponent } from './users/viewuser/viewuser.component';
import { UpdateuserComponent } from './users/updateuser/updateuser.component';


@NgModule({
  declarations: [
    AppComponent,
    HotelComponent,
    FlightComponent,
    ReviewComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    CreatereviewComponent,
    DeletereviewComponent,
    LogoutComponent,
    FlightbookingsComponent,
    AddflightsComponent,
    DeleteflightsComponent,
    HotelbookingsComponent,
    AddhotelsComponent,
    EldeletehotelsComponent,
    DeletehotelsComponent,
    ViewhotelbookingsComponent,
    ViewflightbookingsComponent,
    FlightreviewsComponent,
    HotelreviewsComponent,
    UsersComponent,
    ViewuserComponent,
    UpdateuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
