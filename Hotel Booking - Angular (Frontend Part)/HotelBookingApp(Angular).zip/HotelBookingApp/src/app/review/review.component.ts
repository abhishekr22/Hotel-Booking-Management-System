import { Component, OnInit } from '@angular/core';
import { Review } from '../review';
import { ReviewService } from '../review.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

  searchText!:any;
  reviews: Review[]=[];
  HotelFlightName!: string;
  searchtext:any;
 

  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.getreviews();
  }
  getreviews(){
    
    this.service.getreviews().subscribe(data=>{this.reviews=data});

  }

createreview(){
  this.router.navigate(['/createreview']);
}
deletereview(reviewid:number){
  this.service.deletereview(reviewid).subscribe(data=>{alert("Record Deleted Successfully");this.getreviews();})

}
search(){
  if(this.HotelFlightName == ""){
    this.ngOnInit();
  }
  this.reviews = this.reviews.filter(res=>{
    return res.hotelname.toLocaleLowerCase().match(this.HotelFlightName.toLocaleLowerCase());
  })
}
sort(){
    this.service.sortratings().subscribe(data=>{this.reviews=data});
  
}

}
