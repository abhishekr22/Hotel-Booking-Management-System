import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Review } from 'src/app/review';
import { ReviewService } from 'src/app/review.service';

@Component({
  selector: 'app-createreview',
  templateUrl: './createreview.component.html',
  styleUrls: ['./createreview.component.css']
})
export class CreatereviewComponent implements OnInit {

  review:Review = new Review();
  
  constructor(private rservice:ReviewService,private router:Router) { }
  

  ngOnInit(): void {
  }

  onSubmit(){
    this.rservice.addreviews(this.review).subscribe(data=>{alert("Feedback Submitted Successfully");this.gotoreviews()},error => alert("Data Insertion Failed !!!"));
  }
  gotoreviews(){
    this.router.navigate(['/review']);
  }
}
