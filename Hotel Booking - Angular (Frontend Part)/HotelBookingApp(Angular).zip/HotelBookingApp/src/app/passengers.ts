export class Passengers {
	user_id!:number;
    user_name!:string;
	email!:string;
	password!:string;
	mobile!:string;
	address!:string;
}
