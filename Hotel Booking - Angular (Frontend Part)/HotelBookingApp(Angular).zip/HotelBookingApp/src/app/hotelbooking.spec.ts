import { Hotelbooking } from './hotelbooking';

describe('Hotelbooking', () => {
  it('should create an instance', () => {
    expect(new Hotelbooking()).toBeTruthy();
  });
});
