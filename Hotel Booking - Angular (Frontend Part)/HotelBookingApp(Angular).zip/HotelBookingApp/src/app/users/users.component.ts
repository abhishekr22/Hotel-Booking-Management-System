import { Component, OnInit } from '@angular/core';
import { Passengers } from '../passengers';
import { ReviewService } from '../review.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  searchtext!:any;
  passengers:Passengers []=[];
  constructor(private service:ReviewService,private router: Router) { }

  ngOnInit(): void {
    this.getusers();
  }
  getusers(){
    this.service.getusers().subscribe(data=>{this.passengers=data});

  }
  deleteuser(user_id:number){
    this.service.deleteuser(user_id).subscribe(data=>{alert("User "+user_id+" Deleted Successfully");this.getusers();})
    }
  viewuser(user_id:number){
    this.router.navigate(['userdetails',user_id]);
  }
  adduser(){
    this.router.navigate(['signup']);
  }


}
