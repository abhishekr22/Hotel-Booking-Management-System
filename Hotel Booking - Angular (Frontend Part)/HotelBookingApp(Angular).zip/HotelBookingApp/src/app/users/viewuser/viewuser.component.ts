import { Component, OnInit } from '@angular/core';
import { Passengers } from 'src/app/passengers';
import { ReviewService } from 'src/app/review.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {

  user_id!:number;
  passengers!:any;
  
  searchtext!:any;

  constructor(private service:ReviewService,private router: ActivatedRoute) { }

  ngOnInit(): void {
    this.user_id=this.router.snapshot.params['user_id'];
    this.service.viewuser(this.user_id).subscribe(data=>{this.passengers=data});
  }

}
