export class Hotelbooking {
    booking_id!:number;
	hotelId!:number;
	city!:string;
	fromDate!:Date;
	toDate!:Date;
	user_id!:number;
	cost!:number;
}
