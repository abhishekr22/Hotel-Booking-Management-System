import { Passengers } from './passengers';

describe('Passengers', () => {
  it('should create an instance', () => {
    expect(new Passengers()).toBeTruthy();
  });
});
