export class Flightbooking {
    bookingid!:number;
    flightId!:number;
	departure!:string;
	destination!:string;
	noofpassengers!:number;
	onDate!:Date;
	cost!:number;
	user_id!:number;
}

